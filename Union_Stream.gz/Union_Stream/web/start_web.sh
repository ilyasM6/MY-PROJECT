#!/bin/bash
# start_web.sh - Démarre l'interface web Ebro_Stream

PORT=8080
WEB_DIR="/usr/lib/enigma2/python/Plugins/Extensions/Ebro_Stream/web"

echo "=========================================="
echo "     Ebro_Stream Web Interface v2.0       "
echo "=========================================="

# Vérifier si Python est installé
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 n'est pas installé!"
    exit 1
fi

# Vérifier si le répertoire web existe
if [ ! -d "$WEB_DIR" ]; then
    echo "📁 Création du répertoire web..."
    mkdir -p "$WEB_DIR"
fi

# Copier les fichiers si nécessaires
if [ ! -f "$WEB_DIR/index.html" ]; then
    echo "📄 Copie de l'interface web..."
    cp /tmp/ebro_stream_web/index.html "$WEB_DIR/"
    cp /tmp/ebro_stream_web/api.py "$WEB_DIR/"
fi

# Se déplacer dans le répertoire
cd "$WEB_DIR"

# Vérifier si le port est déjà utilisé
if netstat -tuln | grep ":$PORT " > /dev/null; then
    echo "⚠️  Le port $PORT est déjà utilisé!"
    echo "📌 Tentative d'arrêt du processus existant..."
    fuser -k $PORT/tcp > /dev/null 2>&1
    sleep 2
fi

# Démarrer le serveur
echo "🚀 Démarrage du serveur web sur le port $PORT..."
echo "🌐 Interface: http://$(hostname -I | awk '{print $1}'):$PORT"
echo ""
echo "📋 Commandes disponibles:"
echo "   • Ctrl+C : Arrêter le serveur"
echo "   • ./start_web.sh stop : Arrêter proprement"
echo ""

# Démarrer en arrière-plan et garder le PID
python3 api.py &
WEB_PID=$!
echo $WEB_PID > /tmp/ebro_stream_web.pid

echo "✅ Serveur démarré avec PID: $WEB_PID"
echo "📌 PID sauvegardé dans: /tmp/ebro_stream_web.pid"

# Fonction de nettoyage
cleanup() {
    echo ""
    echo "🛑 Arrêt du serveur web..."
    kill $WEB_PID 2>/dev/null
    rm -f /tmp/ebro_stream_web.pid
    exit 0
}

# Capturer Ctrl+C
trap cleanup INT TERM

# Attendre
wait $WEB_PID