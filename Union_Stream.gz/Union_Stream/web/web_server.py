#!/usr/bin/python3
"""
Serveur web personnalisé pour Union_Stream
"""

import http.server
import socketserver
import json
import os
import subprocess
import urllib.parse

PORT = 8181
WEB_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/web"
PID_FILE = "/tmp/union_stream_web.pid"

class UnionStreamHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB_DIR, **kwargs)
    
    def do_GET(self):
        """Gère les requêtes GET"""
        # Extraire le chemin et les paramètres
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query_params = urllib.parse.parse_qs(parsed_path.query)
        
        # Si c'est une route API
        if path.startswith('/api'):
            if path == '/api/status':
                self.handle_api_status()
            elif path == '/api/start':
                self.handle_api_start()
            elif path == '/api/stop':
                self.handle_api_stop()
            elif path == '/api/command':
                command = query_params.get('command', [None])[0]
                self.handle_api_command(command)
            else:
                self.send_error(404, "API endpoint not found")
        else:
            # Servir les fichiers statiques
            super().do_GET()
    
    def do_POST(self):
        """Gère les requêtes POST"""
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        
        # Parser les données POST (on suppose du JSON)
        try:
            data = json.loads(post_data) if post_data else {}
        except:
            data = {}
        
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        
        if path == '/api/start':
            self.handle_api_start()
        elif path == '/api/stop':
            self.handle_api_stop()
        elif path == '/api/command':
            command = data.get('command', '')
            self.handle_api_command(command)
        else:
            self.send_error(404, "API endpoint not found")
    
    def handle_api_status(self):
        """Retourne le statut du serveur"""
        import socket
        # Vérifier si le serveur tourne (c'est à dire, le port est en écoute)
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('127.0.0.1', PORT))
            running = result == 0
            sock.close()
        except:
            running = False
        
        # Obtenir l'adresse IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            ip = "localhost"
        
        response = {
            "status": "running" if running else "stopped",
            "port": PORT,
            "ip": ip,
            "url": f"http://{ip}:{PORT}",
            "version": "1.0"
        }
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(response).encode('utf-8'))
    
    def handle_api_start(self):
        """Démarre le serveur web (en fait, il est déjà démarré, donc on ne fait que confirmer)"""
        # Note: Le serveur est déjà démarré, donc on ne fait que retourner un message
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response = {"status": "running", "message": "Server is already running"}
        self.wfile.write(json.dumps(response).encode('utf-8'))
    
    def handle_api_stop(self):
        """Arrête le serveur web"""
        # Note: Nous ne pouvons pas arrêter le serveur depuis une requête car cela arrêterait le serveur et il ne pourrait pas répondre.
        # Donc, nous allons juste retourner un message et le serveur ne sera pas arrêté par cette requête.
        # Pour arrêter le serveur, il faut utiliser le script shell.
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        response = {"status": "stopped", "message": "Server stop requested (but not implemented via API)"}
        self.wfile.write(json.dumps(response).encode('utf-8'))
    
    def handle_api_command(self, command):
        """Traite une commande"""
        if command == 'restart':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {"status": "restarting", "message": "Restart requested"}
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            self.send_response(400)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            response = {"error": "Unknown command"}
            self.wfile.write(json.dumps(response).encode('utf-8'))
    
    def log_message(self, format, *args):
        """Journalise les messages"""
        print(f"[WebServer] {format % args}")

def run_server():
    """Démarre le serveur web"""
    os.chdir(WEB_DIR)
    
    with socketserver.TCPServer(("", PORT), UnionStreamHTTPRequestHandler) as httpd:
        print(f"Server starting on port {PORT}")
        # Sauvegarder le PID
        with open(PID_FILE, 'w') as f:
            f.write(str(os.getpid()))
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Server stopped by user")
        finally:
            if os.path.exists(PID_FILE):
                os.remove(PID_FILE)

if __name__ == "__main__":
    run_server()