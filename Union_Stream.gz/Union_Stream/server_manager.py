#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Server Manager for Union_Stream Plugin
Gestionnaire unifié des serveurs Stalker et Xtream
"""

import json
import os
import re
import ssl
import socket
import urllib.request
import urllib.parse
import uuid
from datetime import datetime

class ServerManager:
    """
    Gestionnaire unifié des serveurs Stalker et Xtream.
    """
    
    def __init__(self, config_path=None):
        """
        Initialise le gestionnaire de serveurs.
        
        Args:
            config_path (str): Chemin vers le fichier de configuration.
        """
        # Chemin par défaut
        if config_path is None:
            self.config_dir = "/etc/enigma2/Union_Stream/"
            self.config_file_name = "servers.json"
            self.config_path = os.path.join(self.config_dir, self.config_file_name)
        else:
            self.config_path = config_path
            self.config_dir = os.path.dirname(config_path)
        
        # Migration depuis les anciens fichiers
        self._migrate_from_old_files()
        
        # Liste des serveurs
        self.servers = []
        self.active_server = None
        
        # Charger la configuration
        self.load_config()
        
        # Fichier de log
        self.log_file = os.path.join(self.config_dir, "server_manager.log")
    
    def _migrate_from_old_files(self):
        """Migre depuis les anciens fichiers portals.json et xtream.json"""
        old_portals = "/etc/enigma2/Union_Stream/portals.json"
        old_xtream = "/etc/enigma2/Union_Stream/xtream.json"
        
        if os.path.exists(old_portals) and not os.path.exists(self.config_path):
            try:
                os.makedirs(self.config_dir, exist_ok=True)
                
                with open(old_portals, 'r') as f:
                    portals_data = json.load(f)
                
                migrated_servers = []
                
                # Convertir portals Stalker
                if "portals" in portals_data:
                    for portal in portals_data["portals"]:
                        server = {
                            "id": str(uuid.uuid4())[:8],
                            "type": "stalker",
                            "name": portal.get('name', 'Stalker Server'),
                            "host": portal.get('host', ''),
                            "mac": portal.get('mac', '00:1A:79:00:00:00'),
                            "username": None,
                            "password": None,
                            "active": portal.get('active', False),
                            "created": datetime.now().isoformat(),
                            "last_used": portal.get('last_used'),
                            "tested": portal.get('tested', False),
                            "test_result": portal.get('test_result', '')
                        }
                        migrated_servers.append(server)
                
                # Sauvegarder
                data = {"servers": migrated_servers}
                with open(self.config_path, 'w') as f:
                    json.dump(data, f, indent=2)
                
                # Renommer l'ancien fichier
                os.rename(old_portals, f"{old_portals}.backup")
                
                self.log(f"Migration depuis portals.json: {len(migrated_servers)} serveurs")
                
            except Exception as e:
                self.log(f"Erreur migration portals.json: {e}", "ERROR")
        
        # Migration Xtream (si existe)
        if os.path.exists(old_xtream):
            try:
                with open(old_xtream, 'r') as f:
                    xtream_data = json.load(f)
                
                xtream_servers = []
                
                if "xtream_connections" in xtream_data:
                    for conn in xtream_data["xtream_connections"]:
                        server = {
                            "id": str(uuid.uuid4())[:8],
                            "type": "xtream",
                            "name": conn.get('name', 'Xtream Server'),
                            "host": conn.get('url', ''),
                            "mac": "00:1A:79:00:00:00",  # MAC par défaut pour Xtream
                            "username": conn.get('username', ''),
                            "password": conn.get('password', ''),
                            "active": conn.get('active', False),
                            "created": datetime.now().isoformat(),
                            "last_used": None,
                            "tested": False,
                            "test_result": ""
                        }
                        xtream_servers.append(server)
                
                # Charger les serveurs existants
                if os.path.exists(self.config_path):
                    with open(self.config_path, 'r') as f:
                        existing_data = json.load(f)
                    existing_servers = existing_data.get("servers", [])
                else:
                    existing_servers = []
                
                # Fusionner
                existing_servers.extend(xtream_servers)
                data = {"servers": existing_servers}
                
                with open(self.config_path, 'w') as f:
                    json.dump(data, f, indent=2)
                
                # Renommer l'ancien fichier
                os.rename(old_xtream, f"{old_xtream}.backup")
                
                self.log(f"Migration depuis xtream.json: {len(xtream_servers)} serveurs")
                
            except Exception as e:
                self.log(f"Erreur migration xtream.json: {e}", "ERROR")
    
    def load_config(self):
        """Charge la configuration"""
        try:
            if not os.path.exists(self.config_dir):
                os.makedirs(self.config_dir, exist_ok=True)
            
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                self.servers = data.get("servers", [])
                
                # Normaliser les serveurs
                for server in self.servers:
                    self._normalize_server(server)
                
                # Trouver le serveur actif
                for server in self.servers:
                    if server.get("active", False):
                        self.active_server = server
                        break
                
                self.log(f"Configuration chargée: {len(self.servers)} serveurs")
                return True
            else:
                # Créer une configuration vide
                self.servers = []
                self._create_empty_config()
                return True
                
        except Exception as e:
            self.log(f"Erreur chargement: {e}", "ERROR")
            self.servers = []
            return False
    
    def save_config(self):
        """Sauvegarde la configuration"""
        try:
            data = {
                "servers": self.servers,
                "metadata": {
                    "last_modified": datetime.now().isoformat(),
                    "total_servers": len(self.servers),
                    "version": "2.0"
                }
            }
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            self.log(f"Configuration sauvegardée: {len(self.servers)} serveurs")
            return True
            
        except Exception as e:
            self.log(f"Erreur sauvegarde: {e}", "ERROR")
            return False
    
    def _create_empty_config(self):
        """Crée une configuration vide"""
        self.servers = []
        self.save_config()
    
    def _normalize_server(self, server):
        """Normalise les données d'un serveur"""
        if "id" not in server:
            server["id"] = str(uuid.uuid4())[:8]
        
        if "type" not in server:
            server["type"] = "stalker"  # Par défaut
        
        if "name" not in server:
            server["name"] = "Serveur sans nom"
        
        if "host" not in server:
            server["host"] = ""
        
        if server["type"] == "stalker":
            if "mac" not in server:
                server["mac"] = "00:1A:79:00:00:00"
            else:
                server["mac"] = self.format_mac_address(server["mac"])
        
        if server["type"] == "xtream":
            if "username" not in server:
                server["username"] = ""
            if "password" not in server:
                server["password"] = ""
        
        if "active" not in server:
            server["active"] = False
        
        if "created" not in server:
            server["created"] = datetime.now().isoformat()
        
        if "tested" not in server:
            server["tested"] = False
        if "test_result" not in server:
            server["test_result"] = ""
    
    def get_servers(self, server_type=None):
        """
        Retourne la liste des serveurs.
        
        Args:
            server_type (str): 'stalker', 'xtream', ou None pour tous
            
        Returns:
            list: Liste des serveurs
        """
        if server_type:
            return [s for s in self.servers if s.get("type") == server_type]
        return self.servers
    
    def get_server(self, index):
        """Retourne un serveur par index"""
        if 0 <= index < len(self.servers):
            return self.servers[index]
        return None
    
    def add_server(self, server_type, **kwargs):
        """
        Ajoute un nouveau serveur.
        
        Args:
            server_type (str): 'stalker' ou 'xtream'
            **kwargs: Données du serveur
            
        Returns:
            dict: Résultat de l'opération
        """
        name = kwargs.get("name", "").strip()
        host = kwargs.get("host", "").strip()
        
        if not name:
            return {'success': False, 'message': "Le nom est requis"}
        if not host:
            return {'success': False, 'message': "L'URL est requise"}
        
        # Vérifier les doublons
        for server in self.servers:
            if server["name"] == name:
                return {'success': False, 'message': f"Le serveur '{name}' existe déjà"}
        
        # Créer le serveur
        new_server = {
            "id": str(uuid.uuid4())[:8],
            "type": server_type,
            "name": name,
            "host": host,
            "active": False,
            "created": datetime.now().isoformat(),
            "last_used": None,
            "tested": False,
            "test_result": ""
        }
        
        if server_type == "stalker":
            mac = kwargs.get("mac", "00:1A:79:00:00:00")
            new_server["mac"] = self.format_mac_address(mac)
            new_server["username"] = None
            new_server["password"] = None
            
        elif server_type == "xtream":
            new_server["mac"] = "00:1A:79:00:00:00"
            new_server["username"] = kwargs.get("username", "").strip()
            new_server["password"] = kwargs.get("password", "").strip()
            
            if not new_server["username"]:
                return {'success': False, 'message': "Nom d'utilisateur requis pour Xtream"}
            if not new_server["password"]:
                return {'success': False, 'message': "Mot de passe requis pour Xtream"}
        
        # Tester la connexion (optionnel)
        test_connection = kwargs.get("test_connection", True)
        if test_connection:
            success, message = self.test_connection(new_server)
            new_server["tested"] = True
            new_server["test_result"] = message
            
            if not success:
                return {'success': False, 'message': f"Test de connexion échoué: {message}"}
        
        # Ajouter
        self.servers.insert(0, new_server)
        
        # Si premier serveur, l'activer
        if len(self.servers) == 1:
            new_server["active"] = True
            self.active_server = new_server
        
        # Sauvegarder
        if self.save_config():
            self.log(f"Serveur ajouté: {name} ({server_type})")
            return {
                'success': True,
                'message': f"Serveur '{name}' ajouté avec succès!",
                'server': new_server
            }
        else:
            self.servers.pop(0)
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def update_server(self, index, **kwargs):
        """
        Met à jour un serveur.
        
        Args:
            index (int): Index du serveur
            **kwargs: Données à mettre à jour
            
        Returns:
            dict: Résultat
        """
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}
        
        server = self.servers[index]
        old_active = server.get("active", False)
        
        # Mettre à jour les champs
        if "name" in kwargs and kwargs["name"]:
            new_name = kwargs["name"].strip()
            if new_name != server["name"]:
                # Vérifier doublon
                for s in self.servers:
                    if s != server and s["name"] == new_name:
                        return {'success': False, 'message': f"Le nom '{new_name}' existe déjà"}
                server["name"] = new_name
        
        if "host" in kwargs and kwargs["host"]:
            server["host"] = kwargs["host"].strip()
        
        if server["type"] == "stalker" and "mac" in kwargs:
            server["mac"] = self.format_mac_address(kwargs["mac"])
        
        if server["type"] == "xtream":
            if "username" in kwargs:
                server["username"] = kwargs["username"].strip()
            if "password" in kwargs:
                server["password"] = kwargs["password"].strip()
        
        if "active" in kwargs:
            server["active"] = kwargs["active"]
        
        # Tester la connexion
        if kwargs.get("test_connection", False):
            success, message = self.test_connection(server)
            server["tested"] = True
            server["test_result"] = message
            
            if not success:
                return {'success': False, 'message': f"Test échoué: {message}"}
        
        # Gérer l'activation
        if server["active"] and not old_active:
            # Désactiver les autres
            for s in self.servers:
                if s != server:
                    s["active"] = False
            self.active_server = server
        
        server["last_modified"] = datetime.now().isoformat()
        
        if self.save_config():
            self.log(f"Serveur mis à jour: {server['name']}")
            return {'success': True, 'message': "Serveur mis à jour"}
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def delete_server(self, index):
        """
        Supprime un serveur.
        
        Args:
            index (int): Index du serveur
            
        Returns:
            dict: Résultat
        """
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}
        
        server = self.servers[index]
        server_name = server["name"]
        was_active = server["active"]
        
        del self.servers[index]
        
        # Si serveur actif supprimé, activer un autre
        if was_active and self.servers:
            self.servers[0]["active"] = True
            self.active_server = self.servers[0]
        
        if self.save_config():
            self.log(f"Serveur supprimé: {server_name}")
            return {'success': True, 'message': f"Serveur '{server_name}' supprimé"}
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def set_active_server(self, index):
        """
        Active un serveur.
        
        Args:
            index (int): Index du serveur
            
        Returns:
            dict: Résultat
        """
        if not (0 <= index < len(self.servers)):
            return {'success': False, 'message': "Index invalide"}
        
        server = self.servers[index]
        
        # Désactiver tous
        for s in self.servers:
            s["active"] = False
        
        # Activer celui-ci
        server["active"] = True
        self.active_server = server
        server["last_used"] = datetime.now().isoformat()
        
        # Tester la connexion
        success, message = self.test_connection(server)
        server["tested"] = True
        server["test_result"] = message
        
        if self.save_config():
            msg = f"Serveur '{server['name']}' activé"
            if success:
                msg += f"\nTest: ✅ {message}"
            else:
                msg += f"\nTest: ❌ {message}"
            
            self.log(f"Serveur activé: {server['name']}")
            return {
                'success': success,
                'message': msg,
                'test_result': message
            }
        else:
            return {'success': False, 'message': "Erreur sauvegarde"}
    
    def test_connection(self, server):
        """
        Teste la connexion à un serveur.
        
        Args:
            server (dict): Données du serveur
            
        Returns:
            tuple: (success, message)
        """
        if server["type"] == "stalker":
            return self._test_stalker_connection(server)
        elif server["type"] == "xtream":
            return self._test_xtream_connection(server)
        else:
            return False, "Type de serveur inconnu"
    
    def _test_stalker_connection(self, server):
        """Teste un serveur Stalker"""
        try:
            host = server["host"].rstrip("/")
            mac = server["mac"]
            
            portal_url = f"{host}/server/load.php"
            url = f"{portal_url}?{urllib.parse.urlencode({'type': 'stb', 'action': 'handshake'})}"
            
            headers = {"User-Agent": "MAG254", "Cookie": f"mac={mac};"}
            
            req = urllib.request.Request(url, headers=headers)
            response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=10)
            
            data = json.loads(response.read().decode('utf-8'))
            token = data.get("js", {}).get("token")
            
            if token:
                return True, f"Connecté - Token: {token[:15]}..."
            return False, "Pas de token reçu"
            
        except Exception as e:
            return False, f"Erreur: {str(e)[:50]}"
    
    def _test_xtream_connection(self, server):
        """Teste un serveur Xtream"""
        try:
            import requests
            
            host = server["host"].rstrip("/")
            username = server["username"]
            password = server["password"]
            
            # Test de connexion Xtream API
            test_url = f"{host}/player_api.php?username={username}&password={password}"
            
            response = requests.get(test_url, timeout=10)
            data = response.json()
            
            if "user_info" in data:
                return True, f"Connecté - {data['user_info'].get('username', '')}"
            return False, "Réponse API invalide"
            
        except Exception as e:
            return False, f"Erreur: {str(e)[:50]}"
    
    def format_mac_address(self, mac):
        """Formate une adresse MAC"""
        if not mac:
            return "00:00:00:00:00:00"
        
        mac = mac.strip().upper()
        mac = re.sub(r'[^0-9A-F]', '', mac)
        
        if len(mac) < 12:
            mac = mac.ljust(12, '0')
        else:
            mac = mac[:12]
        
        return ':'.join([mac[i:i+2] for i in range(0, 12, 2)])
    
    def validate_mac_address(self, mac):
        """Valide une adresse MAC"""
        pattern = r'^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$'
        return bool(re.match(pattern, mac))
    
    def get_active_server(self):
        """Retourne le serveur actif"""
        for server in self.servers:
            if server.get("active", False):
                return server
        return None
    
    def get_active_server_index(self):
        """Retourne l'index du serveur actif"""
        for i, server in enumerate(self.servers):
            if server.get("active", False):
                return i
        return -1
    
    def get_summary(self):
        """Retourne un résumé"""
        total = len(self.servers)
        active = sum(1 for s in self.servers if s.get("active", False))
        stalker_count = sum(1 for s in self.servers if s.get("type") == "stalker")
        xtream_count = sum(1 for s in self.servers if s.get("type") == "xtream")
        
        active_server = self.get_active_server()
        active_info = None
        if active_server:
            active_info = {
                'name': active_server['name'],
                'type': active_server['type'],
                'host': active_server['host']
            }
        
        return {
            "total": total,
            "active": active,
            "stalker": stalker_count,
            "xtream": xtream_count,
            "active_server": active_info
        }
    
    def log(self, message, level="INFO"):
        """Enregistre un log"""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_entry = f"[{timestamp}] [ServerManager] [{level}] {message}\n"
            
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(log_entry)
            
            print(f"ServerManager: {log_entry.strip()}")
            
        except Exception as e:
            print(f"Erreur log: {e}")


def get_server_manager():
    """Retourne une instance du gestionnaire"""
    return ServerManager()