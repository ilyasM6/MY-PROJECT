#!/usr/bin/python
# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo, ConfigInteger
from threading import Thread
import subprocess
import os

# Configuration
config.plugins.Ebro_Stream_web = ConfigSubsection()
config.plugins.Ebro_Stream_web.enabled = ConfigYesNo(default=False)
config.plugins.Ebro_Stream_web.port = ConfigInteger(default=8080, limits=(1024, 65535))

def start_web_interface():
    """Démarre l'interface web"""
    port = config.plugins.Ebro_Stream_web.port.value
    web_dir = "/usr/lib/enigma2/python/Plugins/Extensions/Ebro_Stream/web"
    
    if not os.path.exists(web_dir):
        os.makedirs(web_dir, exist_ok=True)
    
    # Démarrer le serveur en arrière-plan
    cmd = f"cd {web_dir} && python3 api.py --port {port}"
    subprocess.Popen(cmd, shell=True)
    
    return True

def stop_web_interface():
    """Arrête l'interface web"""
    subprocess.Popen("pkill -f 'python3 api.py'", shell=True)
    return True

def setup(session, **kwargs):
    """Configuration de l'interface web"""
    from Screens.Setup import Setup
    from Components.config import getConfigListEntry
    
    class WebInterfaceSetup(Setup):
        def __init__(self, session):
            Setup.__init__(self, session, "web_interface")
            
            self.list = []
            self.list.append(getConfigListEntry(
                "Activer l'interface web",
                config.plugins.Ebro_Stream_web.enabled
            ))
            self.list.append(getConfigListEntry(
                "Port HTTP",
                config.plugins.Ebro_Stream_web.port
            ))
            
            self["config"].list = self.list
            self["config"].l.setList(self.list)
        
        def keySave(self):
            Setup.keySave(self)
            
            # Démarrer/Arrêter selon la configuration
            if config.plugins.Ebro_Stream_web.enabled.value:
                start_web_interface()
                self.session.open(MessageBox,
                    f"Interface web démarrée sur le port {config.plugins.Ebro_Stream_web.port.value}",
                    MessageBox.TYPE_INFO
                )
            else:
                stop_web_interface()
                self.session.open(MessageBox,
                    "Interface web arrêtée",
                    MessageBox.TYPE_INFO
                )
    
    session.open(WebInterfaceSetup)

def autostart(reason, **kwargs):
    """Démarrage automatique au démarrage d'Enigma2"""
    if reason == 0:  # Startup
        if config.plugins.Ebro_Stream_web.enabled.value:
            # Démarrer avec un délai pour laisser le système se charger
            import threading
            import time
            
            def delayed_start():
                time.sleep(30)  # 30 secondes après le démarrage
                if config.plugins.Ebro_Stream_web.enabled.value:
                    start_web_interface()
            
            thread = threading.Thread(target=delayed_start)
            thread.daemon = True
            thread.start()

def Plugins(**kwargs):
    """Liste des plugins"""
    return [
        PluginDescriptor(
            name="Ebro_Stream  Web Interface by Said M.S",
            description="Interface web pour la configuration des serveurs",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="web.png",
            fnc=setup
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        )
    ]