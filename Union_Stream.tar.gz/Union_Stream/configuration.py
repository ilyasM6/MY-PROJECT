#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigSubsection, ConfigText, ConfigPassword, ConfigSelection, getConfigListEntry
from Components.Label import Label
from Components.Button import Button
import json
import os
import re
from datetime import datetime

class ConfigurationScreen(ConfigListScreen, Screen):
    """Configuration screen for server management - Version 1920x1080"""
    
    skin = """
        <screen position="center,center" size="1920,1080" title="Union_Stream Configuration">
            <!-- Background Image -->
            <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" zPosition="-1"/>
            
            <!-- Title and subtitle -->
            <widget name="title" position="300,80" size="1320,80" font="Bold;48" halign="center" valign="center" foregroundColor="white"/>
            <widget name="subtitle" position="300,180" size="1320,40" font="Regular;32" halign="center" valign="center" foregroundColor="#CCCCCC"/>
            
            <!-- Left side: Server Information -->
            <eLabel position="100,250" size="800,600" backgroundColor="#19181c" transparent="0" zPosition="1"/>
            <widget name="server_info" position="120,270" size="760,640" font="Regular;32" backgroundColor="#19181c" transparent="1" foregroundColor="white" valign="top" halign="left"/>
            
            <!-- Right side: Configuration fields -->
            <eLabel position="940,250" size="880,600" backgroundColor="#19181c" transparent="0" zPosition="1"/>
            <widget name="config" position="960,270" size="840,550" itemHeight="60" backgroundColor="#19181c" scrollbarMode="showOnDemand" foregroundColor="white" zPosition="2"/>
            
            <!-- Buttons at bottom - 4 boutons maintenant (avec bleu) -->
            <widget name="btn_save" position="340,920" size="300,80" font="Bold;32" halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <widget name="btn_delete" position="660,920" size="300,80" font="Bold;32" halign="center" valign="center" backgroundColor="#ff0000" foregroundColor="white"/>
            <widget name="btn_edit" position="980,920" size="300,80" font="Bold;32" halign="center" valign="center" backgroundColor="#ffff00" foregroundColor="black"/>
            <widget name="btn_reload" position="1300,920" size="300,80" font="Bold;32" halign="center" valign="center" backgroundColor="#0000ff" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session, edit_index=None):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [], session=session)
        
        # EDIT MODE: Si on vient de portals_list.py
        self.edit_index = edit_index
        self.edit_mode = edit_index is not None
        
        # Utiliser PortalManager comme source unique
        try:
            from .server_manager import ServerManager
            self.manager = ServerManager()
            self.servers = self.manager.get_servers('all')  # Obtenir tous les types
        except ImportError as e:
            self.manager = None
            self.servers = []
            print(f"[Configuration] PortalManager import error: {e}")
        
        # Titre
        title_text = "✏️ Éditer Serveur" if self.edit_mode else "➕ Ajouter Serveur"
        self["title"] = Label(title_text)
        self["subtitle"] = Label("Configurez votre serveur Stalker / Xtream")
        
        # Informations serveur
        self["server_info"] = Label("")
        
        # Configuration fields
        self.config_data = ConfigSubsection()
        self.config_data.server_id = ConfigText(default="", fixed_size=False)
        self.config_data.server_name = ConfigText(default="myserver", fixed_size=False)
        self.config_data.server_type = ConfigSelection(choices=[
            ("stalker", "Stalker Portal"),
            ("xtream", "Xtream Codes")
        ], default="stalker")
        self.config_data.server_host = ConfigText(default="http://myserver.com:8080", fixed_size=False)
        self.config_data.server_mac = ConfigText(default="00:1A:79:AA:1B:CD", fixed_size=False)
        self.config_data.server_user = ConfigText(default="user", fixed_size=False)
        self.config_data.server_pass = ConfigPassword(default="pass", fixed_size=False)
        
        # Initialiser la liste de configuration
        self.createConfigList()
        
        # Boutons - 4 maintenant
        self["btn_save"] = Button("💾 Save" if self.edit_mode else "➕ Add")
        self["btn_delete"] = Button("🗑️ Delete")
        self["btn_edit"] = Button("✏️ Edit")
        self["btn_reload"] = Button("🔄 Reload")
        
        # Variables de navigation
        self.current_index = 0  # Index du serveur courant
        
        # Charger les données si en mode édition
        if self.edit_mode and self.edit_index is not None and self.edit_index < len(self.servers):
            self.load_server_data(self.edit_index)
        else:
            self.update_server_info("Nouveau serveur. Remplissez les champs.")
        
        # Actions
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.keyRed,
            "green": self.keyGreen,
            "yellow": self.keyYellow,
            "blue": self.keyBlue,
            "cancel": self.keyCancel,
            "save": self.keyGreen,  # Sauvegarder
        }, -2)
        
        # Pas besoin de redéfinir up/down/left/right, ConfigListScreen les gère
        
        print(f"[Configuration] Screen initialisé (mode: {'édition' if self.edit_mode else 'ajout'})")
    
    def createConfigList(self):
        """Crée la liste de configuration en fonction du type de serveur"""
        config_list = []
        
        # Champs toujours visibles
        config_list.append(getConfigListEntry("🆔 Server ID", self.config_data.server_id))
        config_list.append(getConfigListEntry("📛 Server Name", self.config_data.server_name))
        config_list.append(getConfigListEntry("📋 Server Type", self.config_data.server_type))
        config_list.append(getConfigListEntry("🌐 Server URL", self.config_data.server_host))
        
        # Champs conditionnels
        if self.config_data.server_type.value == "stalker":
            config_list.append(getConfigListEntry("🔑 MAC Address", self.config_data.server_mac))
        elif self.config_data.server_type.value == "xtream":
            config_list.append(getConfigListEntry("👤 Username", self.config_data.server_user))
            config_list.append(getConfigListEntry("🔒 Password", self.config_data.server_pass))
        
        # Mettre à jour la liste
        self["config"].setList(config_list)
    
    def keyLeft(self):
        """Navigation gauche - ConfigListScreen s'en occupe"""
        ConfigListScreen.keyLeft(self)
        # Si on a changé le type de serveur, mettre à jour la liste
        if self["config"].getCurrent() and self["config"].getCurrent()[0] == "📋 Server Type":
            self.createConfigList()
    
    def keyRight(self):
        """Navigation droite - ConfigListScreen s'en occupe"""
        ConfigListScreen.keyRight(self)
        # Si on a changé le type de serveur, mettre à jour la liste
        if self["config"].getCurrent() and self["config"].getCurrent()[0] == "📋 Server Type":
            self.createConfigList()
    
    def keyOK(self):
        """Action OK - ConfigListScreen gère l'édition des champs"""
        ConfigListScreen.keyOK(self)
        # Si on vient de changer le type de serveur, mettre à jour la liste
        if self["config"].getCurrent() and self["config"].getCurrent()[0] == "📋 Server Type":
            self.createConfigList()
    
    def load_server_data(self, index):
        """Charge les données d'un serveur via PortalManager"""
        try:
            if not self.manager or index >= len(self.servers):
                return
            
            server = self.servers[index]
            self.config_data.server_id.value = server.get('id', '')
            self.config_data.server_name.value = server.get('name', '')
            self.config_data.server_type.value = server.get('type', 'stalker')
            self.config_data.server_host.value = server.get('host', '')
            self.config_data.server_mac.value = server.get('mac', '')
            self.config_data.server_user.value = server.get('user', '')
            self.config_data.server_pass.value = server.get('password', '')
            self.current_index = index
            
            # Mettre à jour la liste de configuration
            self.createConfigList()
            self.update_server_info()
            
            print(f"[Configuration] Chargé serveur {index}: {server.get('name')}")
            
        except Exception as e:
            print(f"[Configuration] Erreur chargement serveur: {e}")
    
    def update_server_info(self, message=None):
        """Met à jour les informations affichées"""
        try:
            if message:
                info_text = message
            elif self.servers and 0 <= self.current_index < len(self.servers):
                server = self.servers[self.current_index]
                server_type = server.get('type', 'stalker')
                
                info_text = f"📋 INFORMATIONS SERVEUR\n\n"
                info_text += f"🆔 ID: {server.get('id', 'N/A')}\n\n"
                info_text += f"📛 Nom: {server.get('name', 'N/A')}\n\n"
                info_text += f"📋 Type: {server_type.upper()}\n\n"
                
                host = server.get('host', 'N/A')
                if len(host) > 50:
                    host = host[:47] + "..."
                info_text += f"🌐 URL: {host}\n\n"
                
                # Afficher MAC uniquement pour Stalker
                if server_type == "stalker":
                    info_text += f"🔑 MAC: {server.get('mac', 'N/A')}\n\n"
                
                # Afficher User/Password uniquement pour Xtream
                if server_type == "xtream":
                    user = server.get('user', 'N/A')
                    if user:
                        info_text += f"👤 Utilisateur: {user}\n\n"
                    
                    passwd = server.get('password', '')
                    if passwd:
                        info_text += f"🔒 Mot de passe: {'*' * min(len(passwd), 8)}\n\n"
                
                info_text += f"📊 Statut: {'🟢 ACTIF' if server.get('active', False) else '⚪ INACTIF'}\n\n"
                info_text += f"🔢 Index: {self.current_index + 1}/{len(self.servers)}"
            elif self.servers and len(self.servers) > 0:
                self.current_index = 0
                self.load_server_data(0)
                return
            else:
                info_text = "📋 INFORMATIONS SERVEUR\n\nAucun serveur configuré\n\nAjoutez un serveur avec le formulaire"
            
            self["server_info"].setText(info_text)
        except Exception as e:
            print(f"[Configuration] Erreur update_server_info: {e}")
    
    # ==================== ACTIONS DES BOUTONS ====================
    
    def keyGreen(self):
        """Bouton Vert = Sauvegarder/Ajouter"""
        self.save_server()
    
    def keyRed(self):
        """Bouton Rouge = Supprimer"""
        self.delete_server()
    
    def keyYellow(self):
        """Bouton Jaune = Éditer"""
        self.edit_server()
    
    def keyBlue(self):
        """Bouton Bleu = Recharger"""
        self.reload_servers()
    
    def keyCancel(self):
        """Bouton Annuler = Quitter"""
        self.close()
    
    # ==================== ACTIONS DES SERVEURS ====================
    
    def save_server(self):
        """Sauvegarde un serveur via PortalManager"""
        if not self.manager:
            self.session.open(MessageBox, "❌ PortalManager non disponible", MessageBox.TYPE_ERROR)
            return
        
        server_id = self.config_data.server_id.value.strip()
        name = self.config_data.server_name.value.strip()
        server_type = self.config_data.server_type.value
        host = self.config_data.server_host.value.strip()
        mac = self.config_data.server_mac.value.strip()
        user = self.config_data.server_user.value.strip()
        password = self.config_data.server_pass.value.strip()
        
        print(f"[Configuration] Sauvegarde - ID: '{server_id}', Nom: '{name}', Type: '{server_type}', Host: '{host}'")
        
        # Validation
        validation_errors = []
        
        if not server_id:
            validation_errors.append("L'ID du serveur est requis")
        
        if not name:
            validation_errors.append("Le nom du serveur est requis")
        
        if not host:
            validation_errors.append("L'URL du serveur est requise")
        elif not host.startswith(('http://', 'https://')):
            validation_errors.append("L'URL doit commencer par http:// ou https://")
        
        # Validation spécifique par type
        if server_type == "stalker":
            if not mac:
                validation_errors.append("L'adresse MAC est requise pour Stalker")
        elif server_type == "xtream":
            if not user:
                validation_errors.append("Le nom d'utilisateur est requis pour Xtream")
            if not password:
                validation_errors.append("Le mot de passe est requis pour Xtream")
        
        if validation_errors:
            error_message = "❌ Veuillez corriger:\n\n" + "\n".join(f"• {error}" for error in validation_errors)
            self.session.open(MessageBox, error_message, MessageBox.TYPE_ERROR)
            return
        
        try:
            # Formater l'adresse MAC seulement pour Stalker
            formatted_mac = ""
            if server_type == "stalker" and mac:
                formatted_mac = self.manager.format_mac_address(mac)
                
                if not self.manager.validate_mac_address(formatted_mac):
                    self.session.open(
                        MessageBox,
                        "❌ Adresse MAC invalide!\n\nFormat: 00:1A:79:XX:XX:XX",
                        MessageBox.TYPE_ERROR
                    )
                    return
            
            if self.edit_mode and 0 <= self.current_index < len(self.servers):
                # MODE ÉDITION
                result = self.manager.update_server(
                    index=self.current_index,
                    server_id=server_id,
                    name=name,
                    server_type=server_type,
                    host=host,
                    mac=formatted_mac if server_type == "stalker" else "",
                    user=user if server_type == "xtream" else "",
                    password=password if server_type == "xtream" else "",
                    test_connection=True
                )
                
                if result['success']:
                    self.servers = self.manager.get_servers('all')
                    message = f"✅ Serveur '{name}' mis à jour!\n\nType: {server_type.upper()}\n\n{result.get('message', 'Succès')}"
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
                    
                    # Retour à l'écran précédent
                    self.close(True)
                else:
                    self.session.open(
                        MessageBox,
                        f"❌ Erreur:\n\n{result.get('message', 'Erreur inconnue')}",
                        MessageBox.TYPE_ERROR
                    )
                    
            else:
                # MODE AJOUT
                result = self.manager.add_server(
                    server_id=server_id,
                    name=name,
                    server_type=server_type,
                    host=host,
                    mac=formatted_mac if server_type == "stalker" else "",
                    user=user if server_type == "xtream" else "",
                    password=password if server_type == "xtream" else "",
                    test_connection=True,
                    timeout=30
                )
                
                if result['success']:
                    self.servers = self.manager.get_servers('all')
                    self.current_index = len(self.servers) - 1
                    self.load_server_data(self.current_index)
                    
                    message = f"✅ Serveur '{name}' ajouté!\n\nType: {server_type.upper()}\n\n{result.get('message', 'Succès')}"
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
                else:
                    self.session.open(
                        MessageBox,
                        f"❌ Erreur:\n\n{result.get('message', 'Erreur inconnue')}",
                        MessageBox.TYPE_ERROR
                    )
            
        except Exception as e:
            print(f"[Configuration] Erreur sauvegarde: {e}")
            self.session.open(
                MessageBox,
                f"❌ Erreur technique:\n\n{str(e)[:100]}",
                MessageBox.TYPE_ERROR
            )
    
    def delete_server(self):
        """Supprime un serveur via PortalManager"""
        if not self.manager or not self.servers or self.current_index >= len(self.servers):
            self.session.open(MessageBox, "❌ Aucun serveur à supprimer", MessageBox.TYPE_ERROR)
            return
        
        server = self.servers[self.current_index]
        server_name = server.get('name', 'Serveur inconnu')
        
        # Demander confirmation
        self.session.openWithCallback(
            lambda result: self.confirm_delete(result, self.current_index, server_name),
            MessageBox,
            f"⚠️ SUPPRIMER le serveur?\n\nNom: {server_name}\nType: {server.get('type', 'N/A')}\n\nCette action est irréversible!",
            MessageBox.TYPE_YESNO
        )
    
    def confirm_delete(self, result, index, server_name):
        """Confirme la suppression"""
        if not result:
            return
        
        try:
            # Supprimer via PortalManager
            delete_result = self.manager.delete_server(index)
            
            if delete_result['success']:
                # Mettre à jour la liste locale
                self.servers = self.manager.get_servers('all')
                
                # Ajuster l'index
                if index < self.current_index:
                    self.current_index -= 1
                elif index == self.current_index:
                    self.current_index = max(0, len(self.servers) - 1)
                
                # Recharger ou effacer
                if self.servers and len(self.servers) > 0:
                    self.load_server_data(self.current_index)
                    message = f"✅ {delete_result.get('message', 'Serveur supprimé')}"
                else:
                    # Plus de serveurs, effacer les champs
                    self.config_data.server_id.value = ""
                    self.config_data.server_name.value = "myserver"
                    self.config_data.server_type.value = "stalker"
                    self.config_data.server_host.value = "http://myserver.com:8080"
                    self.config_data.server_mac.value = "00:1A:79:AA:1B:CD"
                    self.config_data.server_user.value = "user"
                    self.config_data.server_pass.value = "pass"
                    self.createConfigList()
                    self.update_server_info("Aucun serveur restant. Ajoutez-en un nouveau.")
                    message = f"✅ {delete_result.get('message', 'Serveur supprimé')}\n\nAucun serveur restant."
                
                self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(
                    MessageBox,
                    f"❌ Erreur:\n\n{delete_result.get('message', 'Erreur inconnue')}",
                    MessageBox.TYPE_ERROR
                )
                
        except Exception as e:
            print(f"[Configuration] Erreur suppression: {e}")
            self.session.open(
                MessageBox,
                "❌ Erreur technique lors de la suppression",
                MessageBox.TYPE_ERROR
            )
    
    def edit_server(self):
        """Passe en mode édition du serveur courant"""
        if not self.servers or self.current_index >= len(self.servers):
            self.session.open(MessageBox, "❌ Aucun serveur à éditer", MessageBox.TYPE_ERROR)
            return
        
        print(f"[Configuration] Mode édition activé pour le serveur {self.current_index}")
        # Simplement mettre le focus sur le premier champ
        if len(self["config"].getList()) > 0:
            self["config"].setCurrentIndex(0)
    
    def reload_servers(self):
        """Recharge la liste des serveurs depuis PortalManager"""
        if not self.manager:
            self.session.open(MessageBox, "❌ PortalManager non disponible", MessageBox.TYPE_ERROR)
            return
        
        try:
            # Recharger la liste des serveurs
            old_count = len(self.servers)
            self.servers = self.manager.get_servers('all')
            new_count = len(self.servers)
            
            # Ajuster l'index courant
            if self.current_index >= new_count:
                self.current_index = max(0, new_count - 1)
            
            # Recharger les données du serveur courant
            if self.servers and len(self.servers) > 0:
                self.load_server_data(self.current_index)
                message = f"🔄 Liste des serveurs rechargée\n\nAncien: {old_count} serveurs\nNouveau: {new_count} serveurs"
            else:
                self.update_server_info("Aucun serveur disponible. Ajoutez-en un nouveau.")
                message = "🔄 Liste des serveurs rechargée\n\nAucun serveur disponible."
            
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=2)
            print(f"[Configuration] Serveurs rechargés: {new_count} serveurs")
            
        except Exception as e:
            print(f"[Configuration] Erreur rechargement: {e}")
            self.session.open(
                MessageBox,
                f"❌ Erreur rechargement:\n\n{str(e)[:100]}",
                MessageBox.TYPE_ERROR
            )
    
    def close(self, result=None):
        """Ferme l'écran avec un résultat optionnel"""
        print("[Configuration] Fermeture de l'écran")
        super().close(result)