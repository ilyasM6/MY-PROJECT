
Union_Stream Screens.Screen import Screen
from Components.ActionMap import ActionMap

class VodScreen(Screen):
    skin = """
    <screen name="VodScreen"
            position="center,center"
            size="1920,1080"
            title="VOD">
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {
                "cancel": self.close
            }, -1
        )

