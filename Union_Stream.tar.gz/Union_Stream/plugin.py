#!/usr/bin/python
# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor

def main(session, **kwargs):
    """Main function - Entry point for Enigma2"""
    print("[Union_Stream] Starting Union_Stream plugin...")
    
    try:
        # ENIGMA2 SPECIFIC: Import using absolute path
        # Enigma2 expects imports from Plugins.Extensions.*
        from Plugins.Extensions.Union_Stream.main import Union_StreamMain
        print("[Union_Stream] Successfully imported Union_StreamMain")
        
        # Open the main screen
        return session.open(Union_StreamMain)
        
    except ImportError as e:
        print(f"[Union_Stream] ImportError: {e}")
        
        # Try alternative import method
        try:
            import sys
            import os
            
            # Get plugin directory
            plugin_dir = '/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream'
            
            # Add to sys.path
            if plugin_dir not in sys.path:
                sys.path.append(plugin_dir)
            
            # Try importing again
            import main
            Union_StreamMain = main.Union_StreamMain
            print("[Union_Stream] Imported via sys.path method")
            
            return session.open(Union_StreamMain)
            
        except Exception as e2:
            print(f"[Union_Stream] Alternative import also failed: {e2}")
            
            # Show error to user
            try:
                from Screens.MessageBox import MessageBox
                error_msg = f"Cannot import Union_Stream:\n\n{str(e)}"
                session.open(MessageBox, error_msg, MessageBox.TYPE_ERROR)
            except:
                pass
    
    except Exception as e:
        print(f"[Union_Stream] General error: {e}")
        
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, f"Error: {str(e)[:50]}", MessageBox.TYPE_ERROR)
        except:
            pass
    
    return None

def Plugins(**kwargs):
    """Plugin descriptor for Enigma2"""
    return [
        PluginDescriptor(
            name="Union_Stream",
            description="IPTV Client for Stalker & Xtream by Saïd M.S",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main,
            needsRestart=False
        )
    ]