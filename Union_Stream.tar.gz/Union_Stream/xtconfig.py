#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigList
from Components.config import ConfigSubsection, ConfigText, ConfigYesNo, getConfigListEntry, ConfigPassword
from Components.Label import Label
from Components.Button import Button
from enigma import gRGB
import json
import os
from datetime import datetime

class XtConfigScreen(Screen):
    """
    Écran de configuration Xtream - Interface pour configurer les serveurs Xtream
    """
    
    skin = """
    <screen position="center,center" size="1200,700" title="Xtream Configuration">
        <!-- Background Image -->
        <ePixmap position="0,0" size="1200,700" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" zPosition="-1"/>
        
        <!-- Titre et sous-titre -->
        <widget name="title" position="150,60" size="900,50" font="Bold;36" halign="center" valign="center" foregroundColor="#ffffff"/>
        <widget name="subtitle" position="150,120" size="900,35" font="Regular;26" halign="center" valign="center" foregroundColor="#ffff00"/>
        
        <!-- Zone de configuration -->
        <widget name="config" position="50,180" size="1100,350" itemHeight="45" backgroundColor="#19181c" transparent="0" foregroundColor="#ffffff" scrollbarMode="showOnDemand"/>
        
        <!-- Zone d'information -->
        <widget name="info_label" position="50,550" size="1100,80" font="Regular;22" halign="center" valign="center" foregroundColor="#00ff00" transparent="1"/>
        
        <!-- Boutons -->
        <widget name="key_green" position="100,640" size="200,50" font="Bold;24" halign="center" valign="center" backgroundColor="#006400" foregroundColor="#ffffff"/>
        <widget name="key_red" position="850,640" size="200,50" font="Bold;24" halign="center" valign="center" backgroundColor="#ff0000" foregroundColor="#ffffff"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        
        print("[XtConfig] Initialisation de l'écran de configuration Xtream")
        
        # Titres
        self["title"] = Label("🔧 XtConfig - Configuration Xtream")
        self["subtitle"] = Label("Configurez votre serveur Xtream API")
        self["info_label"] = Label("Utilisez les touches HAUT/BAS pour naviguer, OK pour éditer")
        
        # ==================== CONFIGURATION DES CHAMPS ====================
        # Tous ces champs sont ÉDITABLES par l'utilisateur
        
        self.config = ConfigSubsection()
        
        # 1. Nom du serveur (texte libre)
        self.config.server_name = ConfigText(
            default="Mon Serveur Xtream",  # Valeur par défaut
            fixed_size=False  # Permet un texte de longueur variable
        )
        
        # 2. URL du serveur (commence par http:// ou https://)
        self.config.server_url = ConfigText(
            default="http://",
            fixed_size=False
        )
        
        # 3. Nom d'utilisateur
        self.config.username = ConfigText(
            default="",
            fixed_size=False
        )
        
        # 4. Mot de passe (champ masqué) - Utilisation de ConfigPassword
        self.config.password = ConfigPassword()  # Champ spécifique pour les mots de passe
        
        # 5. Activation du service (case à cocher Oui/Non)
        self.config.enable_xtream = ConfigYesNo(
            default=True  # Activé par défaut
        )
        
        # ==================== CRÉATION DE LA LISTE ====================
        # Cette liste définit l'ordre d'affichage des champs
        
        self.config_list = [
            getConfigListEntry("📛 Nom du serveur", self.config.server_name),
            getConfigListEntry("🌐 URL du serveur (ex: http://serveur.com:8080)", self.config.server_url),
            getConfigListEntry("👤 Nom d'utilisateur", self.config.username),
            getConfigListEntry("🔑 Mot de passe", self.config.password),
            getConfigListEntry("✅ Activer Xtream", self.config.enable_xtream)
        ]
        
        # ==================== WIDGETS ====================
        
        # Liste de configuration interactive
        self["config"] = ConfigList(self.config_list)
        
        # Boutons d'action
        self["key_green"] = Button("💾 SAUVEGARDER")
        self["key_red"] = Button("❌ RETOUR")
        
        # ==================== ACTIONS ====================
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.keyRed,
            "green": self.keyGreen,
            "yellow": self.keyYellow,
            "blue": self.keyBlue,
            "ok": self.keyOk,
            "cancel": self.keyCancel,
            "up": self.keyUp,
            "down": self.keyDown,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -2)
        
        # Initialisation après le rendu
        self.onLayoutFinish.append(self.initFocus)
        
        print("[XtConfig] Écran prêt. Tous les champs sont éditables.")
    
    def initFocus(self):
        """Initialise le focus et charge les données existantes"""
        self.updateFocus()
        self.load_settings()
    
    def updateFocus(self):
        """Active la sélection dans la liste"""
        try:
            self["config"].instance.setSelectionEnable(True)
        except:
            pass
    
    # ==================== ÉDITION DES CHAMPS ====================
    
    def keyOk(self):
        """
        Ouvre l'éditeur pour le champ sélectionné
        Appelé quand l'utilisateur appuie sur OK
        """
        try:
            current = self["config"].getCurrent()
            if current and len(current) > 1:
                config_element = current[1]
                
                # Vérifier si l'élément peut être édité
                if hasattr(config_element, 'enabled') and config_element.enabled:
                    # OUVERTURE DU CLAVIER VIRTUEL
                    # Ceci ouvre le clavier Enigma2 pour saisir du texte
                    
                    # Titre personnalisé selon le champ
                    field_titles = {
                        self.config.server_name: "Nom du serveur",
                        self.config.server_url: "URL du serveur",
                        self.config.username: "Nom d'utilisateur",
                        self.config.password: "Mot de passe"
                    }
                    
                    title = field_titles.get(config_element, "Éditer la valeur")
                    current_value = config_element.value
                    
                    # Ouvrir le clavier virtuel
                    self.session.openWithCallback(
                        lambda new_value: self.valueEntered(new_value, config_element),
                        VirtualKeyBoard,
                        title=title,
                        text=current_value
                    )
                    
                    self["info_label"].setText("⌨️ Saisie en cours...")
                else:
                    # Pour ConfigYesNo (case à cocher), basculer avec gauche/droite
                    if config_element == self.config.enable_xtream:
                        self["info_label"].setText("Utilisez ◄/► pour activer/désactiver")
                    else:
                        self["info_label"].setText("⚠️ Ce champ n'est pas éditable")
                        
        except Exception as e:
            print(f"[XtConfig] Erreur keyOk: {e}")
            self["info_label"].setText("❌ Erreur d'édition")
    
    def valueEntered(self, new_value, config_element):
        """
        Callback après saisie au clavier virtuel
        Met à jour la valeur du champ
        """
        if new_value is not None:  # L'utilisateur a validé (pas annulé)
            config_element.value = new_value
            self["config"].setList(self.config_list)  # Rafraîchir l'affichage
            self["info_label"].setText("✓ Valeur mise à jour")
            print(f"[XtConfig] Champ mis à jour: {new_value[:20]}...")
    
    # ==================== NAVIGATION ====================
    
    def keyUp(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveUp)
    
    def keyDown(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
    
    def keyLeft(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveLeft)
    
    def keyRight(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveRight)
    
    # ==================== GESTION DES FICHIERS ====================
    
    def load_settings(self):
        """
        Charge les données depuis /etc/enigma2/Union_Stream/xtream.json
        Appelé automatiquement au démarrage
        """
        config_path = "/etc/enigma2/Union_Stream/xtream.json"
        
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    data = json.load(f)
                
                if 'xtream' in data:
                    xt_data = data['xtream']
                    
                    # Charger les valeurs dans les champs
                    self.config.server_name.value = xt_data.get('server_name', '')
                    self.config.server_url.value = xt_data.get('server_url', 'http://')
                    self.config.username.value = xt_data.get('username', '')
                    self.config.password.value = xt_data.get('password', '')
                    self.config.enable_xtream.value = xt_data.get('enable_xtream', True)
                    
                    # Mettre à jour l'affichage
                    self["config"].setList(self.config_list)
                    
                    server_name = xt_data.get('server_name', 'Sans nom')
                    self["info_label"].setText(f"✅ Config chargée: {server_name}")
                    print(f"[XtConfig] Configuration chargée: {config_path}")
                    return True
                    
        except Exception as e:
            print(f"[XtConfig] Erreur chargement: {e}")
        
        self["info_label"].setText("ℹ️ Nouvelle configuration")
        return False
    
    def save_settings(self):
        """
        SAUVEGARDE LES DONNÉES dans /etc/enigma2/Union_Stream/xtream.json
        Appelé quand l'utilisateur appuie sur le bouton VERT
        """
        # ==================== VALIDATION ====================
        errors = []
        
        # 1. Vérifier l'URL
        url = self.config.server_url.value.strip()
        if not url:
            errors.append("L'URL est obligatoire")
        elif not (url.startswith('http://') or url.startswith('https://')):
            errors.append("URL doit commencer par http:// ou https://")
        
        # 2. Vérifier le nom d'utilisateur
        username = self.config.username.value.strip()
        if not username:
            errors.append("Le nom d'utilisateur est obligatoire")
        
        # 3. Vérifier le mot de passe
        password = self.config.password.value.strip()
        if not password:
            errors.append("Le mot de passe est obligatoire")
        
        # Si erreurs, les afficher
        if errors:
            error_msg = "❌ CORRIGEZ:\n" + "\n".join([f"• {e}" for e in errors])
            self["info_label"].setText(error_msg)
            
            # Afficher aussi une popup
            self.session.open(
                MessageBox,
                "Impossible de sauvegarder:\n\n" + "\n".join(errors),
                MessageBox.TYPE_ERROR
            )
            return False
        
        # ==================== SAUVEGARDE ====================
        try:
            # Préparer les données
            xtream_data = {
                'server_name': self.config.server_name.value.strip() or "Mon Serveur Xtream",
                'server_url': url,
                'username': username,
                'password': password,
                'enable_xtream': self.config.enable_xtream.value,
                'last_updated': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            data = {'xtream': xtream_data}
            
            # Créer le dossier si nécessaire
            config_dir = "/etc/enigma2/Union_Stream"
            os.makedirs(config_dir, exist_ok=True)
            
            # Sauvegarder dans le fichier
            config_file = os.path.join(config_dir, "xtream.json")
            
            with open(config_file, 'w') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            
            # Message de succès
            success_msg = f"✅ DONNÉES SAUVEGARDÉES!\nFichier: {config_file}"
            self["info_label"].setText(success_msg)
            
            print(f"[XtConfig] =========================================")
            print(f"[XtConfig] ✓ DONNÉES SAUVEGARDÉES AVEC SUCCÈS")
            print(f"[XtConfig] Fichier: {config_file}")
            print(f"[XtConfig] Serveur: {xtream_data['server_name']}")
            print(f"[XtConfig] URL: {xtream_data['server_url']}")
            print(f"[XtConfig] Utilisateur: {xtream_data['username']}")
            print(f"[XtConfig] =========================================")
            
            # Afficher une confirmation à l'utilisateur
            self.session.open(
                MessageBox,
                f"✅ Configuration sauvegardée!\n\n"
                f"Nom: {xtream_data['server_name']}\n"
                f"Fichier: {config_file}",
                MessageBox.TYPE_INFO,
                timeout=5  # Disparaît après 5 secondes
            )
            
            return True
            
        except Exception as e:
            # En cas d'erreur
            error_msg = f"❌ ERREUR SAUVEGARDE: {str(e)[:50]}"
            self["info_label"].setText(error_msg)
            print(f"[XtConfig] ✗ Erreur sauvegarde: {e}")
            
            self.session.open(
                MessageBox,
                f"❌ Erreur de sauvegarde:\n\n{str(e)[:100]}",
                MessageBox.TYPE_ERROR
            )
            return False
    
    # ==================== ACTIONS DES BOUTONS ====================
    
    def keyGreen(self):
        """Bouton VERT - SAUVEGARDER"""
        print("[XtConfig] === BOUTON SAUVEGARDER PRESSE ===")
        self.save_settings()
    
    def keyRed(self):
        """Bouton ROUGE - RETOUR"""
        print("[XtConfig] Fermeture de l'écran")
        self.close()
    
    def keyYellow(self):
        """Bouton JAUNE - CHARGER"""
        if self.load_settings():
            self.session.open(
                MessageBox,
                "✅ Configuration rechargée depuis le fichier",
                MessageBox.TYPE_INFO,
                timeout=2
            )
    
    def keyBlue(self):
        """Bouton BLEU - TEST"""
        url = self.config.server_url.value
        user = self.config.username.value
        
        self.session.open(
            MessageBox,
            f"🔍 Test de connexion Xtream\n\n"
            f"URL: {url}\n"
            f"Utilisateur: {user}\n\n"
            f"(Fonction de test à implémenter)",
            MessageBox.TYPE_INFO
        )
    
    def keyCancel(self):
        """Bouton CANCEL - RETOUR"""
        self.close()